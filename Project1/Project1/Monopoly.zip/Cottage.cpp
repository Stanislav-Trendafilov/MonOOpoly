#include "Cottage.h"
