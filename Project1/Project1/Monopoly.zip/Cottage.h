#pragma once
class Cottage
{
};

