#pragma once
class Mortage
{
};

