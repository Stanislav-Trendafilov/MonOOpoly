#pragma once
#include "Card.h"

class GroupPaymentCard
{
};

