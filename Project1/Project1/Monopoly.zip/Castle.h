#pragma once
class Castle
{
};

