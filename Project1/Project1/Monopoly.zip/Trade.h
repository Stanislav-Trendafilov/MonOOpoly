#pragma once

class Trade
{
	int firstPlayerId;
	int secondPlayerId;



};

